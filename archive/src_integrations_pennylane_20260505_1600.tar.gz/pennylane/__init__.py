"""PennyLane-specific integrations and utilities."""

from .backends.pennylane_backend import PennyLaneBackendAdapter
from .block_encoding import (
    controlled_entry_oracle_2d,
    exciton_block_encoding,
    entry_oracle_2d,
    one_particle_index_oracle,
    one_particle_f_sum_block_encoding,
    one_particle_sparse_block_encoding,
    qrom_table_2d,
    two_particle_index_oracle,
    two_particle_v_sum_block_encoding,
    two_particle_w_sum_block_encoding,
    two_particle_sparse_block_encoding,
)

__all__ = [
    "PennyLaneBackendAdapter",
    "qrom_table_2d",
    "entry_oracle_2d",
    "controlled_entry_oracle_2d",
    "one_particle_index_oracle",
    "two_particle_index_oracle",
    "one_particle_sparse_block_encoding",
    "two_particle_sparse_block_encoding",
    "one_particle_f_sum_block_encoding",
    "two_particle_w_sum_block_encoding",
    "two_particle_v_sum_block_encoding",
    "exciton_block_encoding",
]
